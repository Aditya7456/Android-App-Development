package com.arshak.foodrunner.util;

public interface Messenger {
    fun passData(id:Int, name:String)
}
