package com.arshak.foodrunner.databases

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [FavRestEntity::class], version = 1)
abstract class FavRestDatabase: RoomDatabase() {

    abstract fun FavRestDao(): FavRestDao
}