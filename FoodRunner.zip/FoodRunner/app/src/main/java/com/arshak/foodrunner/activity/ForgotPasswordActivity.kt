package com.arshak.foodrunner.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.arshak.foodrunner.R

class ForgotPasswordActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)
    }
}




