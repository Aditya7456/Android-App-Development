package com.arshak.foodrunner.databases

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query


@Dao
interface FavRestDao {

    @Insert
    fun insertRestaurant(restaurantEntity: FavRestEntity)

    @Delete
    fun deleteRestaurant(restaurantEntity: FavRestEntity)

    @Query("SELECT * FROM favorites")
    fun getAllRestaurants(): List<FavRestEntity>

    @Query("SELECT * FROM favorites WHERE id = :resId")
    fun getRestaurantById(resId: String): FavRestEntity

}